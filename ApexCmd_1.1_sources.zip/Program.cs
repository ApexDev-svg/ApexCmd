﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

class ApexCMD
{
    static void Main(string[] args)
    {
        // Устанавливаем заголовок окна консоли
        Console.Title = "ApexCMD v1.1";
        
        // Красивое приветствие
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("========================================");
        Console.WriteLine("         ApexCMD Console v1.1           ");
        Console.WriteLine("========================================");
        Console.ResetColor();
        Console.WriteLine("Type 'help' for built-in commands or enter any Windows command.\n");

        while (true)
        {
            DrawPrompt();

            string? input = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(input))
                continue;

            string trimmedInput = input.Trim();
            string commandLower = trimmedInput.ToLower();

            // Встроенные команды ApexCMD
            if (commandLower == "exit")
            {
                break;
            }
            else if (commandLower == "help")
            {
                PrintHelp();
            }
            else if (commandLower == "clear")
            {
                Console.Clear();
            }
            else if (commandLower.StartsWith("cd ") || commandLower == "cd")
            {
                ChangeDirectory(trimmedInput);
            }
            // Системные OS-команды
            else if (commandLower == "os_n")
            {
                ShowOSName();
            }
            else if (commandLower == "os_v")
            {
                ShowOSVersion();
            }
            else if (commandLower == "os_v+n")
            {
                ShowOSNameAndVersion();
            }
            else
            {
                // Перенаправление остальных команд в систему Windows с поддержкой интерактивности
                ExecuteSystemCommand(trimmedInput);
            }
        }
    }

    static void DrawPrompt()
    {
        string currentDir = Directory.GetCurrentDirectory();
        
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.Write("[");
        
        Console.ForegroundColor = ConsoleColor.Red; // Акцентный красный для ApexCMD
        Console.Write("ApexCMD");
        
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.Write("]@");
        
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write(currentDir);
        
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.Write("> ");
        
        Console.ResetColor();
    }

    static void PrintHelp()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\n[ApexCMD Built-in Commands]");
        Console.WriteLine("  help             - Show this help menu");
        Console.WriteLine("  clear            - Clear the screen");
        Console.WriteLine("  cd <path>        - Change current directory");
        Console.WriteLine("  os_n             - Show Operating System name");
        Console.WriteLine("  os_v             - Show Operating System version");
        Console.WriteLine("  os_v+n           - Show both OS name and version");
        Console.WriteLine("  exit             - Exit ApexCMD");
        Console.WriteLine("\n  * Any other command (ping, ipconfig, python, diskpart, etc.) runs directly in Windows.\n");
        Console.ResetColor();
    }

    static void ShowOSName()
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine($"OS Name: {RuntimeInformation.OSDescription}");
        Console.ResetColor();
    }

    static void ShowOSVersion()
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine($"OS Version: {Environment.OSVersion}");
        Console.ResetColor();
    }

    static void ShowOSNameAndVersion()
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine($"OS Name:    {RuntimeInformation.OSDescription}");
        Console.WriteLine($"OS Version: {Environment.OSVersion}");
        Console.WriteLine($"Platform:   {Environment.OSVersion.Platform}");
        Console.ResetColor();
    }

    static void ChangeDirectory(string input)
    {
        try
        {
            string path = input.Substring(2).Trim();

            if (string.IsNullOrEmpty(path))
            {
                Console.WriteLine(Directory.GetCurrentDirectory());
                return;
            }

            if (path.StartsWith("\"") && path.EndsWith("\""))
            {
                path = path.Substring(1, path.Length - 2);
            }

            Directory.SetCurrentDirectory(path);
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"cd error: {ex.Message}");
            Console.ResetColor();
        }
    }

    static void ExecuteSystemCommand(string command)
    {
        try
        {
            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/c {command}",
                WorkingDirectory = Directory.GetCurrentDirectory(),
                UseShellExecute = false // Позволяет корректно передавать потоки и контекст
            };

            using (Process? process = Process.Start(psi))
            {
                if (process != null)
                {
                    process.WaitForExit();
                }
            }
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Execution error: {ex.Message}");
            Console.ResetColor();
        }
    }
}